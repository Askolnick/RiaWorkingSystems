# Tasks MVP — Integration Guide

This package includes:
- Prisma models: `Task`, `TaskAssignee`, `TaskComment`
- Client SDK: `@ria/tasks-client` with a mock implementing create, update, assign, labels, and comments
- Web pages: `/portal/tasks`, `/portal/tasks/new`, `/portal/tasks/[id]`

## Merge steps
1. Merge `_tasks.prisma` into your main `schema.prisma`. Add a unique constraint for `(tenantId, number)` if you maintain per-tenant sequences.
2. Implement server routes to back the `TasksApi` (keep signatures for seamless swap).
3. Add RLS/ACL to scope by `tenantId` and role.

## Assignees: join table vs array
This MVP ships with a **join table** (`TaskAssignee`) to avoid duplication and enable efficient queries (assignee filters, aggregations). If you still prefer an array of `assigneeIds` for certain wiki-like queries, you can mirror a read-only `assigneeIds` computed column or materialized view. Keep _one_ source of truth to avoid drift.
