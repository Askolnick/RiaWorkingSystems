'use client'
import Link from 'next/link'
import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { createMockTasks } from '../../../../packages/tasks-client/src'
const api = createMockTasks()

const statuses: Array<'all'|'backlog'|'todo'|'doing'|'review'|'done'|'archived'> = ['all','backlog','todo','doing','review','done','archived']

export default function TasksCenter(){
  const [q,setQ]=useState(''); const [status,setStatus]=useState<typeof statuses[number]>('all'); const [label,setLabel]=useState(''); const [assignee,setAssignee]=useState('')
  const { data } = useQuery({ queryKey:['tasks', q, status, label, assignee], queryFn:()=>api.tasks.listTasks({ q: q||undefined, status, label: label||undefined, assigneeId: assignee||undefined, sort:'updated' }) })

  const grouped = (data?.items||[]).reduce((acc, t)=>{ const k=t.status; (acc[k]=acc[k]||[]).push(t); return acc }, {} as Record<string, any[]>)

  return <main className='container'>
    <h1>Tasks</h1>
    <div className='card' style={{display:'flex',gap:8,flexWrap:'wrap'}}>
      <input placeholder='Search' value={q} onChange={e=>setQ(e.target.value)} />
      <select value={status} onChange={e=>setStatus(e.target.value as any)}>{statuses.map(s=>(<option key={s} value={s}>{s}</option>))}</select>
      <input placeholder='Label' value={label} onChange={e=>setLabel(e.target.value)} />
      <input placeholder='Assignee (id)' value={assignee} onChange={e=>setAssignee(e.target.value)} />
      <Link href='/portal/tasks/new'><button className='btn'>New task</button></Link>
    </div>

    {/* Kanban view */}
    <div style={{display:'grid', gridTemplateColumns:'repeat(5, 1fr)', gap:12, marginTop:12}}>
      {['backlog','todo','doing','review','done'].map(col=>(
        <div key={col} className='card' style={{minHeight:260}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <h3 style={{margin:0, textTransform:'capitalize'}}>{col}</h3>
            <span className='badge'>{(grouped[col]||[]).length}</span>
          </div>
          <div style={{display:'grid', gap:8, marginTop:8}}>
            {(grouped[col]||[]).map(t=>(
              <Link key={t.id} href={`/portal/tasks/${t.id}`} className='card' style={{padding:12}}>
                <div style={{display:'flex', justifyContent:'space-between'}}>
                  <div><strong>#{t.number}</strong> {t.title}</div>
                  <span className='badge'>{t.priority}</span>
                </div>
                <div style={{fontSize:12, opacity:.7}}>{t.labels.join(', ')}</div>
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  </main>
}
