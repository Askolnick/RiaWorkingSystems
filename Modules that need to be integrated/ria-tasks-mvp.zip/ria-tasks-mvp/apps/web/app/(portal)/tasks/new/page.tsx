'use client'
import { useRouter } from 'next/navigation'
import { useMutation } from '@tanstack/react-query'
import { useState } from 'react'
import { createMockTasks } from '../../../../../packages/tasks-client/src'
const api = createMockTasks()

export default function NewTask(){
  const router = useRouter()
  const [title,setTitle]=useState('New task')
  const [desc,setDesc]=useState('')
  const [labels,setLabels]=useState('mvp,ui')
  const [priority,setPriority]=useState<'low'|'medium'|'high'|'urgent'>('medium')
  const create = useMutation({ mutationFn:()=>api.tasks.createTask({ title, description:desc, labels: labels.split(/[,\s]+/).filter(Boolean), priority }), onSuccess:(t)=>router.replace(`/portal/tasks/${t.id}`) })
  return <main className='container'>
    <h1>Create task</h1>
    <div className='card' style={{display:'grid', gap:8, maxWidth:700}}>
      <input placeholder='Title' value={title} onChange={e=>setTitle(e.target.value)} />
      <textarea rows={8} placeholder='Description (Markdown supported later)' value={desc} onChange={e=>setDesc(e.target.value)} />
      <input placeholder='Labels (comma separated)' value={labels} onChange={e=>setLabels(e.target.value)} />
      <div style={{display:'flex', gap:8, alignItems:'center'}}>
        <label>Priority</label>
        <select value={priority} onChange={e=>setPriority(e.target.value as any)}>
          <option>low</option><option>medium</option><option>high</option><option>urgent</option>
        </select>
      </div>
      <button className='btn' onClick={()=>create.mutate()}>Create</button>
    </div>
  </main>
}
