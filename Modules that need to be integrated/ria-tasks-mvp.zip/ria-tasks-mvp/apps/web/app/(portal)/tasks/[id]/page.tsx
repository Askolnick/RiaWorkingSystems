'use client'
import { useParams } from 'next/navigation'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { createMockTasks } from '../../../../../packages/tasks-client/src'
const api = createMockTasks()

export default function TaskDetail(){
  const { id } = useParams() as { id: string }
  const qc = useQueryClient()
  const { data } = useQuery({ queryKey:['task', id], queryFn:()=>api.tasks.getTask(id) })
  const [comment,setComment]=useState('')
  const upd = useMutation({ mutationFn:(patch:any)=>api.tasks.updateTask(id, patch), onSuccess:()=>qc.invalidateQueries({queryKey:['task',id]}) })
  const addC = useMutation({ mutationFn:()=>api.tasks.addComment(id, comment), onSuccess:()=>{ setComment(''); qc.invalidateQueries({queryKey:['task',id]}) } })
  const addLabel = useMutation({ mutationFn:()=>api.tasks.addLabel(id,'mvp'), onSuccess:()=>qc.invalidateQueries({queryKey:['task',id]}) })
  const rmLabel = useMutation({ mutationFn:()=>api.tasks.removeLabel(id,'mvp'), onSuccess:()=>qc.invalidateQueries({queryKey:['task',id]}) })
  const assign = useMutation({ mutationFn:()=>api.tasks.assign(id,'me'), onSuccess:()=>qc.invalidateQueries({queryKey:['task',id]}) })
  const unassign = useMutation({ mutationFn:()=>api.tasks.unassign(id,'me'), onSuccess:()=>qc.invalidateQueries({queryKey:['task',id]}) })
  if(!data) return <main className='container'>Loading…</main>
  const t = data.task
  return <main className='container' style={{display:'grid', gap:12}}>
    <div className='card'>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1 style={{margin:0}}><span className='badge'>#{t.number}</span> {t.title}</h1>
        <div style={{display:'flex', gap:8}}>
          <button className='btn' onClick={()=>upd.mutate({ status:'doing' })}>Start</button>
          <button className='btn' onClick={()=>upd.mutate({ status:'review' })}>Send to review</button>
          <button className='btn' onClick={()=>upd.mutate({ status:'done' })}>Mark done</button>
        </div>
      </div>
      <div style={{display:'flex', gap:16, flexWrap:'wrap', marginTop:8}}>
        <div><span className='badge'>Status</span> {t.status}</div>
        <div><span className='badge'>Priority</span> {t.priority} <button className='btn secondary' onClick={()=>upd.mutate({ priority:'high' })}>Set High</button></div>
        <div><span className='badge'>Assignees</span> {t.assigneeIds.join(', ')||'(none)'} <button className='btn secondary' onClick={()=>assign.mutate()}>Assign me</button> <button className='btn secondary' onClick={()=>unassign.mutate()}>Unassign me</button></div>
        <div><span className='badge'>Labels</span> {t.labels.join(', ')||'(none)'} <button className='btn secondary' onClick={()=>addLabel.mutate()}>+ mvp</button> <button className='btn secondary' onClick={()=>rmLabel.mutate()}>- mvp</button></div>
      </div>
      <p style={{marginTop:12}}>{t.description||'(no description)'}</p>
    </div>

    <div className='card'>
      <h3>Comments</h3>
      <div>{data.comments.map(c=>(<div key={c.id} style={{padding:'8px 0', borderBottom:'1px solid #eee'}}>
        <div style={{opacity:.7, fontSize:12}}>{new Date(c.createdAt).toLocaleString()}</div>
        <div>{c.bodyMd}</div>
      </div>))}</div>
      <textarea rows={4} placeholder='Add a comment…' value={comment} onChange={e=>setComment(e.target.value)} />
      <div><button className='btn' onClick={()=>addC.mutate()}>Post</button></div>
    </div>
  </main>
}
