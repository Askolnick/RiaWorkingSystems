import type { RiaTasks, TasksApi } from './api'
import type { Task, TaskComment } from './types'

const delay=(ms:number)=>new Promise(r=>setTimeout(r,ms))
const now=()=>new Date().toISOString()

let seq = 1001
const tasks: Task[] = [
  { id:'tsk-1', number:1, type:'task', title:'Set up repo', status:'done', priority:'medium', labels:['eng'], assigneeIds:['me'], updatedAt: now(), createdAt: now() },
  { id:'tsk-2', number:2, type:'feature', title:'Unified inbox MVP', status:'doing', priority:'high', labels:['messaging','mvp'], assigneeIds:['me'], updatedAt: now(), createdAt: now() },
  { id:'tsk-3', number:3, type:'bug', title:'Fix mobile sidebar', status:'todo', priority:'medium', labels:['ui'], assigneeIds:[], updatedAt: now(), createdAt: now() },
]

const comments: Record<string, TaskComment[]> = {
  'tsk-2': [{ id:'c1', taskId:'tsk-2', authorId:'me', bodyMd:'Initial scaffold complete.', createdAt: now() }]
}

function matches(t: Task, q?: string, label?: string, assignee?: string){
  if (q){
    const hay = (t.title + ' ' + (t.description||'') + ' ' + t.labels.join(' ')).toLowerCase()
    if (!hay.includes(q.toLowerCase())) return false
  }
  if (label && !t.labels.includes(label)) return false
  if (assignee && !t.assigneeIds.includes(assignee)) return false
  return true
}

export function createMockTasks(): RiaTasks {
  const api: TasksApi = {
    async listTasks(params){
      await delay(60)
      let items = [...tasks]
      if (params?.status && params.status!=='all') items = items.filter(t=>t.status===params.status)
      if (params?.q || params?.label || params?.assigneeId) items = items.filter(t=>matches(t, params.q, params.label, params.assigneeId))
      if (params?.sort==='priority') items.sort((a,b)=>['low','medium','high','urgent'].indexOf(b.priority)-['low','medium','high','urgent'].indexOf(a.priority))
      if (params?.sort==='due') items.sort((a,b)=>new Date(a.dueAt||'9999').getTime()-new Date(b.dueAt||'9999').getTime())
      if (params?.sort==='updated') items.sort((a,b)=>new Date(b.updatedAt).getTime()-new Date(a.updatedAt).getTime())
      return { items, next: undefined }
    },
    async getTask(id){ await delay(40); const task = tasks.find(t=>t.id===id); if(!task) throw new Error('Not found'); return { task, comments: comments[id]||[] } },
    async createTask(input){
      await delay(80)
      const id = 'tsk-'+(seq++)
      const number = tasks.length+1
      const t: Task = { id, number, type: input.type||'task', title: input.title, description: input.description, status:'todo', priority: input.priority||'medium', labels: input.labels||[], assigneeIds: input.assigneeIds||[], dueAt: input.dueAt, parentId: input.parentId||null, updatedAt: now(), createdAt: now() }
      tasks.push(t); return t
    },
    async updateTask(id, patch){
      await delay(60)
      const i = tasks.findIndex(t=>t.id===id); if (i<0) throw new Error('Not found')
      tasks[i] = { ...tasks[i], ...patch, updatedAt: now() }
      return tasks[i]
    },
    async addComment(taskId, bodyMd){
      await delay(40)
      const c: TaskComment = { id:'c'+Math.random().toString(36).slice(2), taskId, authorId:'me', bodyMd, createdAt: now() }
      comments[taskId] = [...(comments[taskId]||[]), c]
      return c
    },
    async addLabel(taskId, label){ await delay(10); const t=tasks.find(t=>t.id===taskId); if(!t) throw new Error('Not found'); if(!t.labels.includes(label)) t.labels.push(label) },
    async removeLabel(taskId, label){ await delay(10); const t=tasks.find(t=>t.id===taskId); if(!t) throw new Error('Not found'); t.labels=t.labels.filter(l=>l!==label) },
    async assign(taskId, userId){ await delay(10); const t=tasks.find(t=>t.id===taskId); if(!t) throw new Error('Not found'); if(!t.assigneeIds.includes(userId)) t.assigneeIds.push(userId) },
    async unassign(taskId, userId){ await delay(10); const t=tasks.find(t=>t.id===taskId); if(!t) throw new Error('Not found'); t.assigneeIds=t.assigneeIds.filter(id=>id!==userId) },
  }
  return { tasks: api }
}
