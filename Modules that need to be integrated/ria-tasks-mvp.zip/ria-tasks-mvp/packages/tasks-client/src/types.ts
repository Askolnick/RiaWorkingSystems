export type ID = string
export type TaskStatus = 'backlog'|'todo'|'doing'|'review'|'done'|'archived'
export type TaskPriority = 'low'|'medium'|'high'|'urgent'
export type TaskType = 'task'|'bug'|'feature'|'chore'

export interface Task {
  id: ID
  number: number
  type: TaskType
  title: string
  description?: string
  status: TaskStatus
  priority: TaskPriority
  reporterId?: ID
  dueAt?: string
  estimate?: number
  labels: string[]
  assigneeIds: ID[]
  parentId?: ID|null
  updatedAt: string
  createdAt: string
}
export interface TaskComment {
  id: ID
  taskId: ID
  authorId: ID
  bodyMd: string
  createdAt: string
}
