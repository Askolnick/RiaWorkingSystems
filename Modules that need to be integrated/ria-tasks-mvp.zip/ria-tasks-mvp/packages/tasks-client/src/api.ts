import type { ID, Task, TaskStatus, TaskPriority, TaskType, TaskComment } from './types'

export interface TasksApi {
  listTasks(params?: { q?: string; status?: TaskStatus|'all'; label?: string; assigneeId?: ID; sort?: 'updated'|'priority'|'due'; limit?: number; cursor?: string }): Promise<{ items: Task[]; next?: string }>
  getTask(id: ID): Promise<{ task: Task; comments: TaskComment[] }>
  createTask(input: { type?: TaskType; title: string; description?: string; labels?: string[]; assigneeIds?: ID[]; dueAt?: string; priority?: TaskPriority; parentId?: ID|null }): Promise<Task>
  updateTask(id: ID, patch: Partial<Omit<Task, 'id'|'number'|'createdAt'>>): Promise<Task>
  addComment(taskId: ID, bodyMd: string): Promise<TaskComment>
  addLabel(taskId: ID, label: string): Promise<void>
  removeLabel(taskId: ID, label: string): Promise<void>
  assign(taskId: ID, userId: ID): Promise<void>
  unassign(taskId: ID, userId: ID): Promise<void>
}

export interface RiaTasks { tasks: TasksApi }
