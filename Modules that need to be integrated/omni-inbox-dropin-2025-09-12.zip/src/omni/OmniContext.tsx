import React, { createContext, useContext } from "react";
import type { OmniAdapters } from "./types";

const OmniCtx = createContext<OmniAdapters | null>(null);

export const OmniProvider: React.FC<React.PropsWithChildren<OmniAdapters>> = ({ children, ...value }) => {
  return <OmniCtx.Provider value={value}>{children}</OmniCtx.Provider>;
};

export const useOmni = () => {
  const ctx = useContext(OmniCtx);
  if (!ctx) throw new Error("OmniProvider missing");
  return ctx;
};
