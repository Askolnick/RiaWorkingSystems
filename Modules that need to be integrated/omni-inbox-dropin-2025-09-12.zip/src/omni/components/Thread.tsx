import React, { useState } from "react";
import type { Conversation, Message } from "../types";
import { useOmni } from "../OmniContext";
import { sanitizeHtml } from "../lib/sanitize";
import { Composer } from "./Composer";

export const Thread: React.FC<{ convo: Conversation | null; messages: Message[]; onMessages: (m: Message[])=>void; }> = ({ convo, messages, onMessages }) => {
  const { data, connectors } = useOmni();
  const [mode, setMode] = useState<"public"|"note">("public");
  const [busy, setBusy] = useState(false);

  if (!convo) return <div className="p-4 text-sm text-muted-foreground">Select a conversation</div>;

  const send = async (payload: { html?: string; text?: string }) => {
    setBusy(true);
    try {
      if (mode === "note") {
        const created = await data.createInternalNote(convo.id, { conversationId: convo.id, author: { id:"me", name: "Me" }, text: payload.text, html: payload.html } as any);
        onMessages([...messages, { ...created, direction: "note", id: created.id, createdAt: Date.now() }]);
      } else {
        const created = await connectors.postReply({ convoId: convo.id, message: { conversationId: convo.id, author: { id:"me", name: "Me" }, text: payload.text, html: payload.html } as any, as: "reply", visibility: "public" });
        onMessages([...messages, { ...created, direction: "out" }]);
      }
    } finally { setBusy(false); }
  };

  return (
    <div className="flex flex-col h-full">
      <header className="border-b p-3 flex items-center justify-between">
        <div className="font-semibold">{convo.title || convo.source.toUpperCase()}</div>
        <div className="flex items-center gap-2">
          <button className={`btn btn-xs ${mode==="public"?"btn-primary":""}`} onClick={()=>setMode("public")}>Public Reply</button>
          <button className={`btn btn-xs ${mode==="note"?"btn-primary":""}`} onClick={()=>setMode("note")}>Internal Note</button>
        </div>
      </header>
      <div className="flex-1 overflow-y-auto">
        {messages.map(m => (
          <article key={m.id} className="p-3 border-b">
            <div className="text-xs text-muted-foreground flex justify-between">
              <div>{m.direction.toUpperCase()} • {("name" in (m.author as any) ? (m.author as any).name : "User")}</div>
              <div>{new Date(m.createdAt).toLocaleString()}</div>
            </div>
            <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: sanitizeHtml(m.html || (m.text || "").replace(/\n/g,"<br/>")) }} />
          </article>
        ))}
      </div>
      <footer className="p-3 border-t">
        <Composer disabled={busy} onSend={send} />
      </footer>
    </div>
  );
};
