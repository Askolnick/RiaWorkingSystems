import React from "react";
import type { Channel } from "../types";

export const ChannelList: React.FC<{ channels: Channel[]; activeId?: string; onSelect: (id?: string)=>void; }> = ({ channels, activeId, onSelect }) => {
  return (
    <ul className="space-y-1">
      {channels.map(c => (
        <li key={c.id}>
          <button className={`w-full text-left px-2 py-1 rounded hover:bg-muted ${activeId===c.id?"bg-muted":""}`} onClick={()=>onSelect(c.id)}>
            <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ background:c.color || "#999" }}></span>
            {c.name}
          </button>
        </li>
      ))}
    </ul>
  );
};
