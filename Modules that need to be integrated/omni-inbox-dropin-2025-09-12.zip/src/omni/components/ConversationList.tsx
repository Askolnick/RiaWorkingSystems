import React from "react";
import type { Conversation } from "../types";

export const ConversationList: React.FC<{ items: Conversation[]; onOpen: (c: Conversation)=>void; }> = ({ items, onOpen }) => {
  if (!items.length) return <div className="p-4 text-sm text-muted-foreground">No conversations</div>;
  return (
    <ul className="divide-y">
      {items.map(i => (
        <li key={i.id} className="p-3 hover:bg-muted cursor-pointer" onClick={()=>onOpen(i)}>
          <div className="flex items-center justify-between">
            <div className="font-medium truncate">{i.title || i.source.toUpperCase()}</div>
            <div className="text-xs text-muted-foreground">{new Date(i.lastMessageAt).toLocaleString()}</div>
          </div>
          <div className="text-xs text-muted-foreground">#{i.status} • {i.tags.join(", ")}</div>
          <div className="text-xs">{i.assignees.map(a=>a.name).join(", ")}</div>
        </li>
      ))}
    </ul>
  );
};
