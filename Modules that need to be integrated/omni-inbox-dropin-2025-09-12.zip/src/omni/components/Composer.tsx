import React, { useState } from "react";

export const Composer: React.FC<{ disabled?: boolean; onSend: (payload:{ html?: string; text?: string })=>void; }> = ({ disabled, onSend }) => {
  const [value, setValue] = useState("");
  const send = () => { if (!value.trim()) return; onSend({ text: value }); setValue(""); };
  return (
    <div className="flex items-center gap-2">
      <textarea className="textarea flex-1 h-24" placeholder="Write a reply… or switch to Internal Note" value={value} onChange={e=>setValue(e.target.value)} />
      <button className="btn" onClick={send} disabled={disabled}>Send</button>
    </div>
  );
};
