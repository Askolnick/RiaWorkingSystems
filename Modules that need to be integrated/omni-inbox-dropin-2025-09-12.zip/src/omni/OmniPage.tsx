import React, { useEffect, useState } from "react";
import { useOmni } from "./OmniContext";
import type { Channel, Conversation, Message } from "./types";
import { Thread } from "./components/Thread";
import { ConversationList } from "./components/ConversationList";
import { ChannelList } from "./components/ChannelList";

export const OmniPage: React.FC = () => {
  const { data } = useOmni();
  const [channels, setChannels] = useState<Channel[]>([]);
  const [activeChannel, setActiveChannel] = useState<string|undefined>(undefined);
  const [convos, setConvos] = useState<Conversation[]>([]);
  const [activeConvo, setActiveConvo] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [query, setQuery] = useState("");

  useEffect(()=>{ data.listChannels().then(setChannels); }, [data]);
  useEffect(()=>{ data.listConversations({ channelId: activeChannel, q: query }).then(setConvos); }, [data, activeChannel, query]);

  const openConvo = async (c: Conversation) => {
    const { convo, messages } = await data.getConversation(c.id);
    setActiveConvo(convo);
    setMessages(messages);
  };

  return (
    <div className="grid grid-cols-12 h-full">
      <aside className="col-span-2 border-r overflow-y-auto p-2">
        <div className="mb-2 font-semibold text-sm">Channels</div>
        <ChannelList channels={channels} activeId={activeChannel} onSelect={setActiveChannel} />
        <div className="mt-3"><input className="input input-sm w-full" placeholder="Search…" value={query} onChange={e=>setQuery(e.target.value)} /></div>
      </aside>
      <main className="col-span-4 border-r overflow-y-auto">
        <ConversationList items={convos} onOpen={openConvo} />
      </main>
      <section className="col-span-6 overflow-y-auto">
        <Thread convo={activeConvo} messages={messages} onMessages={(m)=>setMessages(m)} />
      </section>
    </div>
  );
};
