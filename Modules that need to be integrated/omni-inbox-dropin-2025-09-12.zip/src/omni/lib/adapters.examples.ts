import type { AuthAdapter, DataAdapter, ConnectorsAdapter, Channel, Conversation, Message, ID } from "../types";

export const AuthExample: AuthAdapter = {
  async getAuthHeaders() {
    const token = localStorage.getItem("token");
    return token ? { Authorization: `Bearer ${token}` } : {};
  }
};

export const DataExample: DataAdapter = {
  async listChannels() {
    return [
      { id: "ch_internal", name: "General", connector: "internal", color: "#5b8" },
      { id: "ch_twitter", name: "Twitter Mentions", connector: "twitter", color: "#1DA1F2" }
    ] as Channel[];
  },
  async listConversations({ channelId }) {
    return [{
      id: "cv_demo",
      channelId: channelId || "ch_internal",
      source: channelId === "ch_twitter" ? "twitter" : "internal",
      status: "open",
      assignees: [{ id:"u1", name:"Alex" }],
      tags: ["demo"],
      lastMessageAt: Date.now(),
      participants: [{ id:"u2", name:"Customer" }],
      title: "Welcome to Omni‑Inbox"
    }];
  },
  async getConversation(id: ID) {
    return {
      convo: {
        id, channelId: "ch_internal", source: "internal",
        status: "open", assignees: [{id:"u1", name:"Alex"}], tags:["demo"],
        lastMessageAt: Date.now(), participants: [{id:"u2", name:"Customer"}],
        title: "Welcome thread"
      },
      messages: [
        { id:"m1", conversationId: id, direction:"in", author:{ name:"Customer" }, createdAt: Date.now()-60000, text:"Hello team!" },
        { id:"m2", conversationId: id, direction:"note", author:{ id:"u1", name:"Alex" }, createdAt: Date.now()-30000, text:"Internal note: triaging." }
      ]
    };
  },
  async setAssignees(){}, async setStatus(){}, async addTag(){}, async removeTag(){},
  async createInternalNote(convoId, note){
    return { id:"note_"+Math.random().toString(36).slice(2), conversationId: convoId, direction:"note", author: note.author!, createdAt: Date.now(), text: note.text } as Message;
  },
  async linkReference(){}, async listReferences(){ return []; }
};

export const ConnectorsExample: ConnectorsAdapter = {
  async listConnectors(){ return [{ type:"twitter", name:"Twitter/X", connected:false }, { type:"instagram", name:"Instagram", connected:false }]; },
  async postReply({ convoId, message, as }) {
    return { id:"out_"+Math.random().toString(36).slice(2), conversationId: convoId, direction:"out", author: message.author as any, createdAt: Date.now(), text: message.text } as Message;
  }
};
