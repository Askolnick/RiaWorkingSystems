export function sanitizeHtml(html: string): string {
  const tmp = document.createElement("div");
  tmp.innerHTML = html;
  tmp.querySelectorAll("script,style,iframe,object,embed").forEach(n=>n.remove());
  tmp.querySelectorAll("*").forEach((el:any)=>{
    [...el.attributes].forEach((a:any)=>{
      if (a.name.startsWith("on")) el.removeAttribute(a.name);
      if (a.name.startsWith("srcdoc")) el.removeAttribute(a.name);
    });
  });
  return tmp.innerHTML;
}
