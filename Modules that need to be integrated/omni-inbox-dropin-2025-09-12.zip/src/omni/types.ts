export type ID = string;

export type ConnectorType = "twitter"|"instagram"|"facebook"|"linkedin"|"email"|"webchat"|string;

export type UserRef = { id: ID; name: string; avatarUrl?: string };

export type ConversationStatus = "open"|"pending"|"snoozed"|"resolved"|"spam";

export type Conversation = {
  id: ID;
  channelId: ID;
  source: ConnectorType;
  externalId?: string;
  title?: string;
  status: ConversationStatus;
  assignees: UserRef[];
  tags: string[];
  lastMessageAt: number;
  participants: UserRef[];
  unread?: boolean;
};

export type Message = {
  id: ID;
  conversationId: ID;
  direction: "in"|"out"|"note";
  author: UserRef | { name: string };
  createdAt: number;
  html?: string;
  text?: string;
  attachments?: { id: string; name: string; size: number; mime: string; url?: string }[];
  metadata?: Record<string, any>;
};

export type Channel = {
  id: ID;
  name: string;
  description?: string;
  color?: string;
  teamIds?: ID[];
  defaultAssigneeIds?: ID[];
  connector: ConnectorType | "internal";
};

export type SLA = { priority: "low"|"normal"|"high"|"urgent"; firstReplyMins?: number; nextReplyMins?: number };

export type AuthAdapter = { getAuthHeaders: () => Promise<Record<string,string>> };

export type DataAdapter = {
  listChannels: () => Promise<Channel[]>;
  listConversations: (opts: { channelId?: ID; q?: string; status?: ConversationStatus[]; tags?: string[]; assigneeId?: ID|null }) => Promise<Conversation[]>;
  getConversation: (id: ID) => Promise<{ convo: Conversation; messages: Message[] }>;
  setAssignees: (id: ID, assigneeIds: ID[]) => Promise<void>;
  setStatus: (id: ID, status: ConversationStatus) => Promise<void>;
  addTag: (id: ID, tag: string) => Promise<void>;
  removeTag: (id: ID, tag: string) => Promise<void>;
  createInternalNote: (convoId: ID, note: Omit<Message, "id"|"direction"|"createdAt">) => Promise<Message>;
  linkReference: (convoId: ID, ref: { type: "task"|"project"|"order"|"inventory"; id: ID; quote?: string }) => Promise<void>;
  listReferences: (convoId: ID) => Promise<{ type: string; id: ID; label?: string }[]>;
};

export type ConnectorsAdapter = {
  listConnectors: () => Promise<{ type: ConnectorType; name: string; connected: boolean }[]>;
  postReply: (opts: { convoId: ID; message: Omit<Message,"id"|"direction"|"createdAt">; as?: "comment"|"dm"|"reply"; visibility?: "public"|"private" }) => Promise<Message>;
  fetchExternalContext?: (convoId: ID) => Promise<any>;
};

export type OmniAdapters = { auth: AuthAdapter; data: DataAdapter; connectors: ConnectorsAdapter };
