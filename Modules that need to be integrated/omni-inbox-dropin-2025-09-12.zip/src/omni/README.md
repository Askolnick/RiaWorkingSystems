# Omni‑Inbox Module (Slack‑alternative + Social Integrations)

**Version:** 2025-09-12

A **drop‑in** React + TypeScript module providing an internal, Slack‑like workspace with **omni‑channel** connectors (social media, email, web forms, etc.). It normalizes external DMs/comments into unified **Conversations** your team can triage, assign, and reply to—together—while keeping an internal/private thread.

See README from previous cell for details.
