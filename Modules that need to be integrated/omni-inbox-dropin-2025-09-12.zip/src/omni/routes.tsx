import React from "react";
import { OmniPage } from "./OmniPage";

export const omniRoutes = [
  { path: "/comms/omni", element: <OmniPage />, title: "Inbox", icon: "MessagesSquare" },
  { path: "/comms/omni/:convoId", element: <OmniPage />, hidden: true },
];
