export default function PortalHome(){
  return <main className='container'>
    <h1>Portal</h1>
    <p>Welcome to your workspace. Use the side nav to open a centre.</p>
  </main>
}
