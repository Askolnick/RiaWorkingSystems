'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from '../providers/SessionProvider'

export default function Protected({ children }:{ children: React.ReactNode }){
  const { session, loading } = useSession()
  const router = useRouter()
  useEffect(()=>{
    if (!loading && !session) router.replace('/auth/sign-in')
  }, [loading, session, router])
  if (loading || !session) return <main className='container'>Loading…</main>
  return <>{children}</>
}
