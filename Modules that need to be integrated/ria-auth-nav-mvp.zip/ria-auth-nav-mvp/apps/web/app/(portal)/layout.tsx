'use client'
import Link from 'next/link'
import Protected from './Protected'
import { useSession } from '../providers/SessionProvider'

function SideNav(){
  const links = [
    { href:'/portal', label:'Home' },
    { href:'/portal/messaging', label:'Messaging' },
    { href:'/portal/tasks', label:'Tasks' },
    { href:'/portal/library', label:'Library' },
    { href:'/portal/insights', label:'Insights' },
    { href:'/portal/finance', label:'Finance' },
    { href:'/portal/product', label:'Product' },
    { href:'/portal/campaigns', label:'Campaigns' },
    { href:'/portal/admin', label:'Admin' },
    { href:'/portal/settings', label:'Settings' },
  ]
  return <aside className='sidebar'>{links.map(l=>(<Link key={l.href} href={l.href}>{l.label}</Link>))}</aside>
}

function TopBar(){
  const { session, signOut } = useSession()
  return <div className='navbar'>
    <div style={{display:'flex', alignItems:'center', gap:10}}>
      <Link href='/portal'><strong>Ria</strong></Link>
      <input placeholder='Quick search…' style={{minWidth:240}} />
    </div>
    <div className='userchip'>
      <span className='badge'>{session?.user.role}</span>
      <span>{session?.user.name||session?.user.email}</span>
      <button className='btn secondary' onClick={()=>signOut()}>Sign out</button>
    </div>
  </div>
}

export default function PortalLayout({ children }:{ children: React.ReactNode }){
  return <Protected>
    <TopBar />
    <div className='layout'>
      <SideNav />
      <div>{children}</div>
    </div>
  </Protected>
}
