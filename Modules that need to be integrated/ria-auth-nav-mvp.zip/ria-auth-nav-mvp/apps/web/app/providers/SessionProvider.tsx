'use client'
import React, { createContext, useContext, useEffect, useState } from 'react'
import { createMockAuth } from '../../../packages/auth-client/src'
import type { Session } from '../../../packages/auth-client/src'
const { auth } = createMockAuth()

type Ctx = { session: Session|null, loading: boolean, refresh: ()=>Promise<void>, signOut: ()=>Promise<void> }
const Ctx = createContext<Ctx>({ session:null, loading:true, refresh: async()=>{}, signOut: async()=>{} })

export function useSession(){ return useContext(Ctx) }

export default function SessionProvider({ children }: { children: React.ReactNode }){
  const [session, setSession] = useState<Session|null>(null)
  const [loading, setLoading] = useState(true)
  const refresh = async ()=>{ setLoading(true); setSession(await auth.getSession()); setLoading(false) }
  const signOut = async ()=>{ await auth.signOut(); await refresh() }
  useEffect(()=>{ refresh() }, [])
  return <Ctx.Provider value={{ session, loading, refresh, signOut }}>{children}</Ctx.Provider>
}
