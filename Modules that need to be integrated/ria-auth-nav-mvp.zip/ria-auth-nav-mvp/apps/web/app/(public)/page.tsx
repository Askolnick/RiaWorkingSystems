import Link from 'next/link'
export default function Landing(){
  return <main className='container'>
    <h1>Ria — Welcome</h1>
    <p>Public landing page placeholder.</p>
    <Link href='/auth/sign-in'>Sign in</Link>
  </main>
}
