'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Button from '../../../components/ui/Button'
import Input from '../../../components/ui/Input'
import { createMockAuth } from '../../../../../packages/auth-client/src'
const { auth } = createMockAuth()
export default function SignUp(){
  const [name,setName]=useState('Ria Admin')
  const [email, setEmail] = useState('admin@ria.test')
  const [password, setPassword] = useState('password')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const onSubmit = async (e: any)=>{ e.preventDefault(); setLoading(true); await auth.signUp(name,email,password,'admin'); setLoading(false); router.replace('/portal') }
  return <main className='container'>
    <div className='card' style={{maxWidth:420, margin:'64px auto'}}>
      <h1>Create account</h1>
      <form onSubmit={onSubmit} style={{display:'grid', gap:10}}>
        <Input placeholder='Name' value={name} onChange={e=>setName(e.target.value)} />
        <Input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
        <Input placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} />
        <Button disabled={loading}>{loading?'Creating…':'Create account'}</Button>
      </form>
      <div style={{marginTop:8}}><a href='/auth/sign-in'>Have an account? Sign in</a></div>
    </div>
  </main>
}
