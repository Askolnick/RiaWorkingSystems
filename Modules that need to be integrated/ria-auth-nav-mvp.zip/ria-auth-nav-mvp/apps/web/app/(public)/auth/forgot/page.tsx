'use client'
import { useState } from 'react'
import Button from '../../../components/ui/Button'
import Input from '../../../components/ui/Input'
export default function Forgot(){
  const [email, setEmail] = useState('admin@ria.test')
  return <main className='container'>
    <div className='card' style={{maxWidth:420, margin:'64px auto'}}>
      <h1>Reset password</h1>
      <p className='badge'>Mock-only: no email will be sent</p>
      <form style={{display:'grid', gap:10}} onSubmit={e=>e.preventDefault()}>
        <Input placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
        <Button>Send reset link</Button>
      </form>
    </div>
  </main>
}
