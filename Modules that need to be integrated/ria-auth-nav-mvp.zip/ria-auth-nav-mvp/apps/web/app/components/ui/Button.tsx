'use client'
import React from 'react'
type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary'|'secondary'|'danger' }
export default function Button({ variant='primary', ...rest }: Props){
  const cls = variant==='secondary' ? 'btn secondary' : 'btn'
  return <button className={cls} {...rest} />
}
