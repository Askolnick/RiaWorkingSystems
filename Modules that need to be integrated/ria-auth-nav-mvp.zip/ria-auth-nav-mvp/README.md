# Ria — Auth + Navigation MVP

This chunk adds a **login system (mocked)** and a **responsive portal shell** with side navigation and a top bar.

## What’s inside
- `@ria/auth-client` — types, API surface, and a **mock** session store (localStorage)
- **SessionProvider** — app-level provider that exposes `useSession()`
- **Protected** component — client-side guard for all `/(portal)` routes
- **Auth pages** — `/auth/sign-in`, `/auth/sign-up`, `/auth/forgot`
- **Portal shell** — left-rail navigation, top bar with quick search, user chip/sign-out
- **UI primitives** — Button, Input, Select; **globals.css** with soft, rounded look

## How to integrate
1. Drop `packages/*` and `apps/*` into your monorepo (or merge files if they already exist).
2. Ensure your Next app uses `/app` directory. If you already have global CSS or layouts, merge them.
3. The mock auth uses **localStorage**. Replace `createMockAuth()` with your real auth adapter later
   (keep `AuthApi` method signatures to avoid UI changes).
4. Start the app and visit `/auth/sign-in`. After login you’ll be routed to `/portal`.

## Next steps
- Role-based **menu filtering** (hide admin items for clients).
- Server-side auth and `middleware.ts` to protect routes with cookies.
- Profile menu, theme switcher, and keyboard shortcuts.
- Nav “Dock” with user-defined quick actions.
