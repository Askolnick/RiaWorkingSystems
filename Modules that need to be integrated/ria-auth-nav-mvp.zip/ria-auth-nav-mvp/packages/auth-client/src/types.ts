export type ID = string
export type Role = 'superadmin'|'admin'|'moderator'|'member'|'guest'|'client'
export interface User { id: ID; email: string; name?: string; role: Role; avatarUrl?: string }
export interface Session { user: User; token: string; expiresAt: string }
