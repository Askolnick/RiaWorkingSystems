import type { Session, User, Role } from './types'

export interface AuthApi {
  signIn(email: string, password: string): Promise<Session>
  signUp(name: string, email: string, password: string, role?: Role): Promise<Session>
  signOut(): Promise<void>
  getSession(): Promise<Session|null>
  updateProfile(p: Partial<User>): Promise<User>
}

export interface RiaAuth { auth: AuthApi }
