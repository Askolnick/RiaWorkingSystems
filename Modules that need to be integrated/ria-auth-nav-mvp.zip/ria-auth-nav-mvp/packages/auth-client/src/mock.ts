import type { RiaAuth, AuthApi } from './api'
import type { Session, User } from './types'

const delay=(ms:number)=>new Promise(r=>setTimeout(r,ms))
const storeKey='ria_session_mock'

function load(): Session|null {
  if (typeof localStorage==='undefined') return null
  const raw = localStorage.getItem(storeKey)
  if (!raw) return null
  try { return JSON.parse(raw) as Session } catch { return null }
}
function save(s: Session|null){
  if (typeof localStorage==='undefined') return
  if (!s) localStorage.removeItem(storeKey)
  else localStorage.setItem(storeKey, JSON.stringify(s))
}
function issueSession(u: User): Session {
  return { user: u, token: 'mock-'+Math.random().toString(36).slice(2), expiresAt: new Date(Date.now()+7*86400000).toISOString() }
}

export function createMockAuth(): RiaAuth {
  const auth: AuthApi = {
    async signIn(email, password){
      await delay(200)
      const role = email.endsWith('@client.test') ? 'client' : 'admin'
      const s = issueSession({ id:'u1', email, name: email.split('@')[0], role })
      save(s); return s
    },
    async signUp(name, email, password, role){
      await delay(250)
      const s = issueSession({ id:'u'+Math.random().toString(36).slice(2), email, name, role: role||'member' })
      save(s); return s
    },
    async signOut(){ await delay(50); save(null) },
    async getSession(){ await delay(50); return load() },
    async updateProfile(p){ await delay(80); const s = load(); if(!s) throw new Error('No session'); const u={...s.user, ...p}; save({...s, user:u}); return u }
  }
  return { auth }
}
