export type User = {
  id: string;
  email: string;
};

export type Session = {
  user: User;
  token: string;
};

// A very simple mock auth API that stores a session in localStorage. In a real
// application you would call an external service and persist tokens
// securely. This implementation is intentionally lightweight so that it can
// be swapped out with a real provider without changing the consuming code.
export const createMockAuth = () => {
  const SESSION_KEY = "ria.auth.session";

  const parseSession = (): Session | null => {
    if (typeof window === "undefined") return null;
    try {
      const raw = window.localStorage.getItem(SESSION_KEY);
      return raw ? (JSON.parse(raw) as Session) : null;
    } catch {
      return null;
    }
  };

  const getSession = async (): Promise<Session | null> => {
    return parseSession();
  };

  const signIn = async (email: string, password: string): Promise<Session> => {
    // In a real app, you would verify the credentials. Here we just create a
    // dummy user and token on the fly.
    const session: Session = {
      user: {
        id: Math.random().toString(36).substring(2),
        email,
      },
      token: Math.random().toString(36).substring(2),
    };
    window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return session;
  };

  const signUp = async (email: string, password: string): Promise<Session> => {
    // Same as sign in for the mock.
    return signIn(email, password);
  };

  const signOut = async (): Promise<void> => {
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(SESSION_KEY);
    }
  };

  return {
    getSession,
    signIn,
    signUp,
    signOut,
  };
};