import type { RiaLibrary, LibraryApi } from './api';
import type { LibraryDoc, LibrarySection, DocPublish } from './types';

// Simple utilities for async mocks
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const now = () => new Date().toISOString();
const rid = (prefix = 'id') => `${prefix}-${Math.random().toString(36).slice(2, 8)}`;

// Seed some initial documents and sections
let docs: LibraryDoc[] = [
  {
    id: 'd1',
    title: 'Company Handbook',
    kind: 'policy',
    status: 'published',
    tags: ['hr', 'policy'],
    bodyMd: '# Welcome to Ria',
    updatedAt: now(),
    createdAt: now(),
  },
  {
    id: 'd2',
    title: 'Engineering Onboarding',
    kind: 'howto',
    status: 'review',
    tags: ['eng', 'onboarding'],
    bodyMd: '## Setup',
    updatedAt: now(),
    createdAt: now(),
  },
  {
    id: 'd3',
    title: 'Product Principles',
    kind: 'memo',
    status: 'draft',
    tags: ['product'],
    bodyMd: 'Focus on clarity.',
    updatedAt: now(),
    createdAt: now(),
  },
];

let sections: LibrarySection[] = [
  { id: 's1', name: 'Support SLA', bodyMd: '**SLA:** 24h first response.', version: 1, createdAt: now(), updatedAt: now() },
  { id: 's2', name: 'Security Statement', bodyMd: 'We follow best practices.', version: 1, createdAt: now(), updatedAt: now() },
];

// Mapping of document ID -> array of section IDs
let uses: Record<string, string[]> = { d1: ['s2'], d2: ['s1'] };

// Publish metadata
let publishes: DocPublish[] = [
  { id: 'p1', docId: 'd1', scope: 'public', userIds: [], groupIds: [], urlPath: '/handbook', createdAt: now() },
];

export function createMockLibrary(): RiaLibrary {
  const library: LibraryApi = {
    async listDocs(params) {
      await delay(30);
      let result = [...docs];
      if (params?.q) {
        const q = params.q.toLowerCase();
        result = result.filter((d) => (d.title + ' ' + (d.tags || []).join(' ')).toLowerCase().includes(q));
      }
      if (params?.status && params.status !== 'all') {
        result = result.filter((d) => d.status === params.status);
      }
      if (params?.kind && params.kind !== 'all') {
        result = result.filter((d) => d.kind === params.kind);
      }
      if (params?.tag) {
        result = result.filter((d) => d.tags.includes(params.tag));
      }
      if (params?.sort === 'created') {
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      } else {
        result.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      }
      return result;
    },
    async getDoc(id) {
      await delay(25);
      const doc = docs.find((d) => d.id === id);
      if (!doc) throw new Error('Not found');
      const secIds = uses[id] || [];
      const sectionsLite = sections
        .filter((s) => secIds.includes(s.id))
        .map((s) => ({ id: s.id, name: s.name, version: s.version }));
      const pubs = publishes.filter((p) => p.docId === id);
      return { doc, sections: sectionsLite, publishes: pubs };
    },
    async createDoc(input) {
      await delay(40);
      const d: LibraryDoc = {
        id: rid('d'),
        title: input.title,
        slug: input.title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)/g, ''),
        kind: input.kind || 'wiki',
        status: 'draft',
        tags: input.tags || [],
        bodyMd: input.bodyMd,
        updatedAt: now(),
        createdAt: now(),
      };
      docs.unshift(d);
      return d;
    },
    async updateDoc(id, patch) {
      await delay(30);
      const i = docs.findIndex((d) => d.id === id);
      if (i < 0) throw new Error('Not found');
      docs[i] = { ...docs[i], ...patch, updatedAt: now() };
      return docs[i];
    },
    async attachSection(docId, sectionId, position = 999) {
      await delay(15);
      const list = uses[docId] || [];
      if (!list.includes(sectionId)) {
        uses[docId] = [...list, sectionId];
      }
    },
    async detachSection(docId, sectionId) {
      await delay(15);
      uses[docId] = (uses[docId] || []).filter((s) => s !== sectionId);
    },
    async listSections(params) {
      await delay(20);
      let r = [...sections];
      if (params?.q) {
        const q = params.q.toLowerCase();
        r = r.filter((s) => (s.name + ' ' + (s.bodyMd || '')).toLowerCase().includes(q));
      }
      return r;
    },
    async createSection(input) {
      await delay(30);
      const s: LibrarySection = {
        id: rid('s'),
        name: input.name,
        bodyMd: input.bodyMd,
        version: 1,
        createdAt: now(),
        updatedAt: now(),
      };
      sections.unshift(s);
      return s;
    },
    async updateSection(id, patch) {
      await delay(30);
      const i = sections.findIndex((s) => s.id === id);
      if (i < 0) throw new Error('Not found');
      sections[i] = { ...sections[i], ...patch, updatedAt: now() };
      return sections[i];
    },
    async listPublishes(docId) {
      await delay(10);
      return publishes.filter((p) => p.docId === docId);
    },
    async upsertPublish(docId, scope, opts) {
      await delay(20);
      let p = publishes.find((x) => x.docId === docId && x.scope === scope);
      if (!p) {
        p = {
          id: rid('p'),
          docId,
          scope,
          userIds: [],
          groupIds: [],
          urlPath: opts.urlPath,
          createdAt: now(),
        };
        publishes.push(p);
      }
      p.userIds = opts.userIds || [];
      p.groupIds = opts.groupIds || [];
      p.urlPath = opts.urlPath;
      return p;
    },
    async removePublish(publishId) {
      await delay(10);
      publishes = publishes.filter((p) => p.id !== publishId);
    },
  };
  return { library };
}