import type { ID, LibraryDoc, LibrarySection, DocPublish, DocStatus, DocKind, PublishScope } from './types';

/**
 * LibraryApi defines the methods required for managing documents and
 * sections. Each method returns a promise to support asynchronous
 * implementations. For the MVP, filters are optional and may be
 * expanded later.
 */
export interface LibraryApi {
  // List documents with optional filters
  listDocs(params?: {
    q?: string;
    status?: DocStatus | 'all';
    kind?: DocKind | 'all';
    tag?: string;
    sort?: 'updated' | 'created';
  }): Promise<LibraryDoc[]>;
  // Get a document and its section / publish info
  getDoc(id: ID): Promise<{ doc: LibraryDoc; sections: { id: ID; name: string; version: number }[]; publishes: DocPublish[] }>;
  // Create a document
  createDoc(input: { title: string; kind?: DocKind; bodyMd?: string; tags?: string[] }): Promise<LibraryDoc>;
  // Update a document
  updateDoc(id: ID, patch: Partial<Omit<LibraryDoc, 'id' | 'createdAt'>>): Promise<LibraryDoc>;
  // Attach a section to a doc
  attachSection(docId: ID, sectionId: ID, position?: number): Promise<void>;
  // Detach a section from a doc
  detachSection(docId: ID, sectionId: ID): Promise<void>;
  // List sections
  listSections(params?: { q?: string }): Promise<LibrarySection[]>;
  // Create a section
  createSection(input: { name: string; bodyMd?: string }): Promise<LibrarySection>;
  // Update a section
  updateSection(id: ID, patch: Partial<Omit<LibrarySection, 'id' | 'createdAt'>>): Promise<LibrarySection>;
  // List publishes
  listPublishes(docId: ID): Promise<DocPublish[]>;
  // Upsert a publish entry
  upsertPublish(docId: ID, scope: PublishScope, opts: { userIds?: ID[]; groupIds?: ID[]; urlPath?: string }): Promise<DocPublish>;
  // Remove a publish entry
  removePublish(publishId: ID): Promise<void>;
}

export interface RiaLibrary {
  library: LibraryApi;
}