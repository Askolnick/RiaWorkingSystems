export type ID = string;
export type DocKind = 'wiki' | 'spec' | 'policy' | 'howto' | 'memo' | 'brief';
export type DocStatus = 'draft' | 'review' | 'scheduled' | 'published' | 'archived';
export type PublishScope = 'private' | 'users' | 'groups' | 'internal' | 'clients' | 'public';

export interface LibraryDoc {
  id: ID;
  title: string;
  slug?: string;
  kind: DocKind;
  status: DocStatus;
  ownerId?: ID;
  tags: string[];
  bodyMd?: string;
  bodyTypist?: any;
  updatedAt: string;
  createdAt: string;
}

export interface LibrarySection {
  id: ID;
  name: string;
  bodyMd?: string;
  bodyTypist?: any;
  version: number;
  updatedAt: string;
  createdAt: string;
}

export interface DocPublish {
  id: ID;
  docId: ID;
  scope: PublishScope;
  userIds: ID[];
  groupIds: ID[];
  urlPath?: string;
  createdAt: string;
}