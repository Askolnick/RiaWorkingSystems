console.log('Boot stub');
