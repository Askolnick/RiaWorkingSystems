"use client";

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createMockAuth } from '@ria/auth-client';

// Basic sign-in page. Uses the mock auth client to persist a session in
// localStorage. When a session exists, it redirects to the portal. This
// page intentionally avoids any styling beyond basic Tailwind classes so
// that it can be easily themed later.
export default function SignInPage() {
  const router = useRouter();
  const auth = createMockAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    auth.getSession().then((session) => {
      if (session) {
        router.replace('/portal');
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await auth.signIn(email, password);
      router.replace('/portal');
    } catch (err) {
      setError('Invalid email or password');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg text-text p-4">
      <div className="w-full max-w-md space-y-4">
        <h1 className="text-2xl font-bold">Sign In</h1>
        {error && <p className="text-danger text-sm">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col">
            <label htmlFor="email" className="mb-1 text-sm">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-md border border-border bg-input px-3 py-2"
              required
            />
          </div>
          <div className="flex flex-col">
            <label htmlFor="password" className="mb-1 text-sm">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-md border border-border bg-input px-3 py-2"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-md bg-primary text-primary-foreground px-4 py-2 font-medium"
          >
            Sign In
          </button>
        </form>
        <p className="text-sm">
          Don’t have an account?{' '}
          <Link href="/auth/sign-up" className="underline">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}