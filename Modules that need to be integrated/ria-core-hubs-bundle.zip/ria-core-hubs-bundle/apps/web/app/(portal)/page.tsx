'use client';
import { Button, Input, Select, FormField } from '../../../packages/web-ui/src';
import { useDisclosure } from '../../../packages/web-hooks/src';

export default function PortalPage() {
  const { isOpen, toggle } = useDisclosure();
  return (
    <main className="p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <div className="flex gap-3 flex-wrap items-center">
        <Button onClick={toggle}>{isOpen ? 'Close' : 'Open'} Modal</Button>
        <Button variant="secondary">Secondary</Button>
        <Button variant="ghost">Ghost</Button>
        <Button variant="danger">Danger</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField label="Search" hint="Type to filter">
          <Input placeholder="Search…" />
        </FormField>
        <FormField label="View">
          <Select
            options={[
              { value: 'all', label: 'All' },
              { value: 'mine', label: 'Assigned to me' },
            ]}
            defaultValue="all"
          />
        </FormField>
      </div>
      <p className="text-sm text-inactive">Tokens are active; toggle dark mode via `.mode-dark` class on `<html>`.</p>
    </main>
  );
}
