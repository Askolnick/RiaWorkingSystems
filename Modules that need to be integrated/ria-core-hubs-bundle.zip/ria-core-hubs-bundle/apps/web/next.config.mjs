export default {
  reactStrictMode: true,
  experimental: {
    typedRoutes: true,
  },
};
