# Messaging MVP — Integration Guide

This package provides a **complete inbox MVP** with filters, actions, labels, snooze, merge, a docked composer, and simple cross‑module intents.

## Contents
- Prisma extension `_messaging.prisma`
- Client SDK `@ria/messaging-client` (types, API, mock)
- Web pages under `/portal/messaging/*`

## Hookup steps
1. Merge `_messaging.prisma` into your main `schema.prisma`. Run migrations.
2. Replace `createMockMessaging()` with your real adapter that implements `MessagingApi`. Keep method signatures.
3. Add RLS/ACL and event ingestion workers for providers (IMAP/SMTP, Gmail/Outlook APIs, chat bridges, portal WS).
4. For **search**, add full‑text index on `Thread.subject` and `Message.bodyText` (or use your global search service).
5. Wire **createTaskFromThread** and **createInvoiceFromThread** to your Tasks and Finance modules.

## UI behaviors
- Inbox filters: text search, status, channel, label, unread‑only.
- Actions: assign/unassign, priority, mark read/unread, add/remove label, snooze, close, merge threads.
- Thread view: shows messages and includes a **docked composer** with “Create Task/Invoice” shortcuts.
