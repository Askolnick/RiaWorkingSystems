'use client'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { createMockMessaging } from '../../../../../packages/messaging-client/src'
const api = createMockMessaging()

export default function Templates(){
  const qc = useQueryClient()
  const { data } = useQuery({ queryKey:['tpl'], queryFn:()=>api.messaging.listTemplates() })
  const upsert = useMutation({ mutationFn:()=>api.messaging.upsertTemplate({ name:'Acknowledgement', bodyMd:'Thanks for reaching out — we will reply shortly.' }), onSuccess:()=>qc.invalidateQueries({queryKey:['tpl']}) })
  return <main className='container'>
    <h1>Templates</h1>
    <ul>{data?.map(t=>(<li key={t.id}><strong>{t.name}</strong> — {t.subject||'(no subject)'} </li>))}</ul>
    <button className='btn' onClick={()=>upsert.mutate()}>Update “Acknowledgement”</button>
  </main>
}
