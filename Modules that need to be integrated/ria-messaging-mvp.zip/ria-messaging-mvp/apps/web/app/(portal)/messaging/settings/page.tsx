'use client'
import { createMockMessaging } from '../../../../../packages/messaging-client/src'
export default function MessagingSettings(){
  createMockMessaging()
  return <main className='container'>
    <h1>Messaging Settings</h1>
    <p>Connect email (IMAP/SMTP), Slack-style chat, and portal channels here.</p>
    <ul>
      <li>• Add an email inbox (support@…)</li>
      <li>• Configure auto-rules (labels, assignment, auto-replies)</li>
      <li>• Set up client portal messaging</li>
      <li>• Social inbox (Twitter/X, etc.) stub</li>
    </ul>
  </main>
}
