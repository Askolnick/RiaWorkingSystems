'use client'
import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { createMockMessaging } from '../../../../../packages/messaging-client/src'
const api = createMockMessaging()

export default function NewMessage(){
  const [to, setTo] = useState('sam@example.com')
  const [subj, setSubj] = useState('Hello from Ria')
  const [body, setBody] = useState('Hi Sam,\n\nJust testing the unified inbox.\n\n— Ria')
  const send = useMutation({ mutationFn:()=>api.messaging.sendMessage({ channelId:'ch-email', to: to.split(/[,\s]+/).filter(Boolean), subject: subj, bodyMd: body }) })
  return <main className='container'>
    <h1>New Message</h1>
    <div className='card'>
      <div style={{display:'grid', gap:8, maxWidth:700}}>
        <input placeholder='To' value={to} onChange={e=>setTo(e.target.value)} />
        <input placeholder='Subject' value={subj} onChange={e=>setSubj(e.target.value)} />
        <textarea rows={10} value={body} onChange={e=>setBody(e.target.value)} />
        <button className='btn' onClick={()=>send.mutate()}>Send</button>
      </div>
    </div>
  </main>
}
