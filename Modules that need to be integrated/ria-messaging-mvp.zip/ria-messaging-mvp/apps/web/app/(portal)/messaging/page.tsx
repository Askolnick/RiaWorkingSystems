'use client'
import Link from 'next/link'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { createMockMessaging } from '../../../../packages/messaging-client/src'
const api = createMockMessaging()

export default function MessagingCenter(){
  const qc = useQueryClient()
  const [q, setQ] = useState('')
  const [status, setStatus] = useState<'open'|'snoozed'|'closed'|''>('')
  const [channel, setChannel] = useState('')
  const [label, setLabel] = useState('')
  const [unreadOnly, setUnreadOnly] = useState(false)

  const { data: channels } = useQuery({ queryKey:['channels'], queryFn:()=>api.messaging.listChannels() })
  const { data: labels } = useQuery({ queryKey:['labels'], queryFn:()=>api.messaging.listLabels() })
  const { data: threads } = useQuery({
    queryKey:['threads', q, status, channel, label, unreadOnly],
    queryFn:()=>api.messaging.listThreads({ q: q||undefined, status: status||undefined, channelId: channel||undefined, label: label||undefined, unreadOnly }),
  })

  const markAllRead = useMutation({ mutationFn: async ()=>{
    await Promise.all((threads?.items||[]).map(t=>api.messaging.markRead(t.id)))
  }, onSuccess:()=>qc.invalidateQueries({queryKey:['threads']}) })

  return <main className='container'>
    <h1>Messaging</h1>
    <div className='card' style={{display:'grid', gap:8}}>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        <input placeholder='Search' value={q} onChange={e=>setQ(e.target.value)} />
        <select value={status} onChange={e=>setStatus(e.target.value as any)}>
          <option value=''>All</option><option value='open'>Open</option><option value='snoozed'>Snoozed</option><option value='closed'>Closed</option>
        </select>
        <select value={channel} onChange={e=>setChannel(e.target.value)}>
          <option value=''>All channels</option>
          {channels?.map(c=>(<option key={c.id} value={c.id}>{c.name}</option>))}
        </select>
        <select value={label} onChange={e=>setLabel(e.target.value)}>
          <option value=''>All labels</option>
          {labels?.map(l=>(<option key={l} value={l}>{l}</option>))}
        </select>
        <label><input type='checkbox' checked={unreadOnly} onChange={e=>setUnreadOnly(e.target.checked)} /> Unread only</label>
        <Link href='/portal/messaging/new'><button className='btn'>New message</button></Link>
        <button className='btn' onClick={()=>markAllRead.mutate()}>Mark listed as read</button>
        <Link href='/portal/messaging/templates'>Templates</Link>
        <Link href='/portal/messaging/settings'>Settings</Link>
      </div>
    </div>
    <table className='table' style={{marginTop:12}}><thead><tr><th>Subject</th><th>Labels</th><th>Channel</th><th>Status</th><th>Priority</th><th>Last activity</th></tr></thead>
      <tbody>{threads?.items.map(t=>(
        <tr key={t.id} style={{fontWeight: t.unread ? 700 : 400}}>
          <td><Link href={`/portal/messaging/t/${t.id}`}>{t.subject||'(no subject)'}</Link></td>
          <td>{/* labels */}{/* placeholder list */}</td>
          <td>{t.channelId}</td><td>{t.status}{t.snoozeUntil?` (until ${new Date(t.snoozeUntil).toLocaleString()})`:''}</td>
          <td>{t.priority}</td>
          <td>{new Date(t.lastActivity).toLocaleString()}</td>
        </tr>
      ))}</tbody>
    </table>
  </main>
}
