'use client'
import { useParams } from 'next/navigation'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { createMockMessaging } from '../../../../../../packages/messaging-client/src'
const api = createMockMessaging()

export default function ThreadView(){
  const { id } = useParams() as { id: string }
  const qc = useQueryClient()
  const { data } = useQuery({ queryKey:['thread', id], queryFn:()=>api.messaging.getThread(id) })
  const [reply, setReply] = useState('')
  const assignMe = useMutation({ mutationFn:()=>api.messaging.assignThread(id,'me'), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const close = useMutation({ mutationFn:()=>api.messaging.setThreadStatus(id,'closed'), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const snooze1d = useMutation({ mutationFn:()=>api.messaging.snooze(id, new Date(Date.now()+86400000).toISOString()), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const high = useMutation({ mutationFn:()=>api.messaging.setPriority(id,'high'), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const addBilling = useMutation({ mutationFn:()=>api.messaging.addLabel(id,'billing'), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const removeBilling = useMutation({ mutationFn:()=>api.messaging.removeLabel(id,'billing'), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const markRead = useMutation({ mutationFn:()=>api.messaging.markRead(id), onSuccess:()=>qc.invalidateQueries({queryKey:['thread',id]}) })
  const send = useMutation({ mutationFn:()=>api.messaging.sendMessage({ threadId:id, channelId:data?.thread.channelId||'ch-email', to:['sam@example.com'], subject:'', bodyMd:reply }), onSuccess:()=>{ setReply(''); qc.invalidateQueries({queryKey:['thread',id]}) } })
  const toTask = useMutation({ mutationFn:()=>api.messaging.createTaskFromThread(id) })
  const toInvoice = useMutation({ mutationFn:()=>api.messaging.createInvoiceFromThread(id) })

  if(!data) return <main className='container'>Loading…</main>
  return <main className='container' style={{display:'grid', gap:12}}>
    <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
      <h1 style={{margin:0}}>{data.thread.subject||'(no subject)'}</h1>
      <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
        <button className='btn' onClick={()=>assignMe.mutate()}>Assign me</button>
        <button className='btn' onClick={()=>high.mutate()}>Set High</button>
        <button className='btn' onClick={()=>snooze1d.mutate()}>Snooze 1d</button>
        <button className='btn' onClick={()=>addBilling.mutate()}>+ billing</button>
        <button className='btn' onClick={()=>removeBilling.mutate()}>- billing</button>
        <button className='btn' onClick={()=>markRead.mutate()}>Mark read</button>
        <button className='btn' onClick={()=>close.mutate()}>Close</button>
      </div>
    </div>
    <div className='card'>
      {data.messages.map(m=>(<div key={m.id} style={{padding:'8px 0', borderBottom:'1px solid #eee'}}>
        <div style={{opacity:.7, fontSize:12}}>{m.authorName||m.authorAddr} — {new Date(m.sentAt||Date.now()).toLocaleString()}</div>
        <div>{m.bodyText}</div>
      </div>))}
      {/* Docked composer */}
      <div style={{position:'sticky', bottom:0, background:'#fff', paddingTop:8 }}>
        <textarea rows={5} placeholder='Reply…' value={reply} onChange={e=>setReply(e.target.value)} style={{width:'100%'}} />
        <div style={{display:'flex', gap:8, marginTop:8}}>
          <button className='btn' onClick={()=>send.mutate()}>Send</button>
          <button className='btn' onClick={()=>toTask.mutate()}>Create Task</button>
          <button className='btn' onClick={()=>toInvoice.mutate()}>Create Invoice</button>
        </div>
      </div>
    </div>
    <div>
      <h3>Labels</h3>
      <ul>{data.labels.map(l=>(<li key={l}>{l}</li>))}</ul>
    </div>
  </main>
}
