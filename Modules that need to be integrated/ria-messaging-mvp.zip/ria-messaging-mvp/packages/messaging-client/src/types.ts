export type ID = string

export type ChannelType = 'email'|'chat'|'portal'|'social'
export type Direction = 'inbound'|'outbound'
export type MessageStatus = 'draft'|'sent'|'delivered'|'read'|'failed'|'archived'
export type Priority = 'low'|'normal'|'high'|'urgent'

export interface Channel { id: ID; type: ChannelType; name: string; address?: string; provider?: string; isActive: boolean }
export interface Thread { id: ID; channelId: ID; subject?: string; preview?: string; status: 'open'|'snoozed'|'closed'; assigneeId?: ID; priority: Priority; unread: boolean; snoozeUntil?: string|null; lastActivity: string }
export interface Message { id: ID; threadId: ID; direction: Direction; status: MessageStatus; authorName?: string; authorAddr?: string; bodyText?: string; bodyHtml?: string; sentAt?: string }
export interface Template { id: ID; name: string; subject?: string; bodyMd: string; updatedAt: string }
export interface MailboxRule { id: ID; name: string; whenCond: any; action: any; isActive: boolean }
