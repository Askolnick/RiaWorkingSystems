import type { RiaMessaging, MessagingApi } from './api'
import type { Channel, Thread, Message, Template, MailboxRule } from './types'

const delay=(ms:number)=>new Promise(r=>setTimeout(r,ms))
const now=()=>new Date().toISOString()

const channels: Channel[] = [
  { id:'ch-email', type:'email', name:'support@ria.app', address:'support@ria.app', provider:'imap', isActive:true },
  { id:'ch-portal', type:'portal', name:'Client Portal', isActive:true },
  { id:'ch-chat', type:'chat', name:'Team Chat', isActive:true },
]

let labels = ['billing','feature','vip']

let threads: Thread[] = [
  { id:'t1', channelId:'ch-email', subject:'Invoice 2025-0001 question', preview:'Hi, could you resend the invoice PDF?', status:'open', assigneeId: null as any, priority:'normal', unread:true, snoozeUntil:null, lastActivity: now() },
  { id:'t2', channelId:'ch-portal', subject:'Feature: Dark mode toggle', preview:'Can we pin the theme switcher?', status:'open', assigneeId: null as any, priority:'high', unread:true, snoozeUntil:null, lastActivity: now() },
  { id:'t3', channelId:'ch-chat', subject:'Internal: Launch checklist', preview:'QA passes, docs, comms', status:'snoozed', assigneeId: null as any, priority:'normal', unread:false, snoozeUntil:new Date(Date.now()+86400000).toISOString(), lastActivity: now() },
]

const threadLabels: Record<string,string[]> = {
  't1': ['billing','vip'],
  't2': ['feature'],
  't3': []
}

const messages: Record<string, Message[]> = {
  't1': [
    { id:'m1', threadId:'t1', direction:'inbound', status:'delivered', authorName:'Sam Client', authorAddr:'sam@example.com', bodyText:'Hi, could you resend the invoice PDF?', sentAt: now() }
  ],
  't2': [
    { id:'m2', threadId:'t2', direction:'inbound', status:'delivered', authorName:'Ava', authorAddr:'client', bodyText:'Can we pin the theme switcher?', sentAt: now() }
  ],
  't3': [
    { id:'m3', threadId:'t3', direction:'inbound', status:'delivered', authorName:'Alex', authorAddr:'team', bodyText:'QA passes, docs, comms', sentAt: now() }
  ]
}

function search(t: Thread, q: string){
  const s = (t.subject||'') + ' ' + (t.preview||'')
  return s.toLowerCase().includes(q.toLowerCase())
}

export function createMockMessaging(): RiaMessaging {
  const api: MessagingApi = {
    async listChannels(){ await delay(40); return channels },
    async listLabels(){ await delay(20); return labels },
    async listThreads(params){
      await delay(60)
      let items = [...threads]
      if (params?.q) items = items.filter(t=>search(t, params.q!))
      if (params?.status) items = items.filter(t=>t.status === params.status)
      if (params?.channelId) items = items.filter(t=>t.channelId === params.channelId)
      if (params?.label) items = items.filter(t=> (threadLabels[t.id]||[]).includes(params.label!))
      if (params?.unreadOnly) items = items.filter(t=>t.unread)
      return { items, next: undefined }
    },
    async getThread(id){
      await delay(40)
      const thread = threads.find(t=>t.id===id); if(!thread) throw new Error('Not found')
      return { thread, messages: messages[id]||[], labels: threadLabels[id]||[] }
    },
    async assignThread(id, assigneeId){
      await delay(30)
      const t = threads.find(t=>t.id===id); if(!t) throw new Error('Not found')
      ;(t as any).assigneeId = assigneeId || undefined
    },
    async setThreadStatus(id, status){
      await delay(30)
      const t = threads.find(t=>t.id===id); if(!t) throw new Error('Not found')
      ;(t as any).status = status
      if (status!=='snoozed') (t as any).snoozeUntil = null
    },
    async setPriority(id, priority){
      await delay(20)
      const t = threads.find(t=>t.id===id); if(!t) throw new Error('Not found')
      ;(t as any).priority = priority
    },
    async markRead(id){
      await delay(15)
      const t = threads.find(t=>t.id===id); if(!t) throw new Error('Not found')
      ;(t as any).unread = false
    },
    async markUnread(id){
      await delay(15)
      const t = threads.find(t=>t.id===id); if(!t) throw new Error('Not found')
      ;(t as any).unread = true
    },
    async addLabel(id, label){
      await delay(10)
      if (!labels.includes(label)) labels.push(label)
      threadLabels[id] = Array.from(new Set([...(threadLabels[id]||[]), label]))
    },
    async removeLabel(id, label){
      await delay(10)
      threadLabels[id] = (threadLabels[id]||[]).filter(l=>l!==label)
    },
    async snooze(id, untilISO){
      await delay(10)
      const t = threads.find(t=>t.id===id); if(!t) throw new Error('Not found')
      ;(t as any).status = 'snoozed'; (t as any).snoozeUntil = untilISO
    },
    async mergeThreads(primaryId, mergeId){
      await delay(50)
      if (!messages[mergeId]) return
      messages[primaryId] = [...(messages[primaryId]||[]), ...messages[mergeId]]
      delete messages[mergeId]
      threads = threads.filter(t=>t.id!==mergeId)
      delete threadLabels[mergeId]
    },
    async sendMessage(input){
      await delay(120)
      const threadId = input.threadId || 't' + (threads.length+1)
      if (!input.threadId) {
        threads.push({ id:threadId, channelId: input.channelId, subject: input.subject, preview: input.bodyMd.slice(0,120), status:'open', assigneeId: undefined, priority:'normal', unread:false, snoozeUntil:null, lastActivity: now() })
        messages[threadId] = []
        threadLabels[threadId] = []
      }
      const messageId = 'm' + (Object.values(messages).flat().length + 1)
      messages[threadId].push({ id:messageId, threadId, direction:'outbound', status:'sent', authorName:'You', authorAddr:'agent', bodyText: input.bodyMd, sentAt: now() })
      return { threadId, messageId }
    },
    async createTaskFromThread(id){ await delay(60); return { taskId: 'task-'+id } },
    async createInvoiceFromThread(id){ await delay(60); return { invoiceId: 'inv-from-'+id } },
    async listTemplates(){ await delay(40); return [{ id:'tpl-ack', name:'Acknowledgement', subject:'We received your message', bodyMd:'Thanks for reaching out — we’ll get back to you shortly.', updatedAt: now() }] },
    async upsertTemplate(t){ await delay(60); return { id:'tpl-ack', name:t.name, subject:t.subject, bodyMd:t.bodyMd, updatedAt: now() } },
    async listMailboxRules(){ await delay(40); return [{ id:'rule-urgent', name:'Mark “urgent” as High Priority', whenCond:{ subjectIncludes:'urgent' }, action:{ setPriority:'high' }, isActive:true }] },
  }
  return { messaging: api }
}
