import type { ID, Channel, Thread, Message, Template, MailboxRule, Priority } from './types'

export interface MessagingApi {
  // inbox + filters
  listChannels(): Promise<Channel[]>
  listLabels(): Promise<string[]>
  listThreads(params?: { q?: string; status?: 'open'|'snoozed'|'closed'; channelId?: ID; label?: string; assignedToMe?: boolean; unreadOnly?: boolean; limit?: number; cursor?: string }): Promise<{ items: Thread[]; next?: string }>
  getThread(id: ID): Promise<{ thread: Thread; messages: Message[]; labels: string[] }>

  // actions
  assignThread(id: ID, assigneeId: ID|null): Promise<void>
  setThreadStatus(id: ID, status: 'open'|'snoozed'|'closed'): Promise<void>
  setPriority(id: ID, priority: Priority): Promise<void>
  markRead(id: ID): Promise<void>
  markUnread(id: ID): Promise<void>
  addLabel(id: ID, label: string): Promise<void>
  removeLabel(id: ID, label: string): Promise<void>
  snooze(id: ID, untilISO: string): Promise<void>
  mergeThreads(primaryId: ID, mergeId: ID): Promise<void>

  // composer
  sendMessage(input: { threadId?: ID; channelId: ID; to: string[]; cc?: string[]; subject?: string; bodyMd: string; attachments?: { name: string; size?: number }[] }): Promise<{ threadId: ID; messageId: ID }>

  // cross-module intents (placeholders)
  createTaskFromThread(id: ID): Promise<{ taskId: ID }>
  createInvoiceFromThread(id: ID): Promise<{ invoiceId: ID }>

  // templates & rules
  listTemplates(): Promise<Template[]>
  upsertTemplate(t: Partial<Template> & { name: string; bodyMd: string }): Promise<Template>
  listMailboxRules(): Promise<MailboxRule[]>
}

export interface RiaMessaging { messaging: MessagingApi }
