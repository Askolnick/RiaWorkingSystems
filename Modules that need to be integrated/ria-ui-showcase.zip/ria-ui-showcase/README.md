# Ria UI Showcase — Admin-only Preview

Run:
```bash
pnpm install
pnpm dev
```
Set `NEXT_PUBLIC_ADMIN_MODE=true` to reveal the full preview.
