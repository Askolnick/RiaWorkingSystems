"use client";

import React from 'react';

/**
 * Textarea is a multi-line input with consistent styling. It forwards
 * additional props to the underlying `<textarea>` element. Provide
 * `className` to add extra classes.
 */
export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  className?: string;
}

export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className = "", ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        className={`w-full rounded-md border border-border bg-input px-3 py-2 text-text placeholder-text/70 focus:outline-none focus:ring-2 focus:ring-primary ${className}`.trim()}
        {...props}
      />
    );
  }
);
Textarea.displayName = "Textarea";

export default Textarea;