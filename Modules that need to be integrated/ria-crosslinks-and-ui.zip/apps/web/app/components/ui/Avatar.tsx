// Simple avatar component that derives initials from a name. Uses inline
// styles so that it remains self‑contained.

'use client'

export default function Avatar({ name = 'U' }: { name?: string }) {
  // Pick first letters of up to two words
  const initials = name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase()
  return (
    <div
      style={{
        width: 28,
        height: 28,
        borderRadius: 999,
        display: 'grid',
        placeItems: 'center',
        border: '1px solid var(--ring)',
        background: 'var(--bg-elev)',
        fontSize: 12,
      }}
    >
      {initials || 'U'}
    </div>
  )
}