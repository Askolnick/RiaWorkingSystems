"use client";

import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';

/**
 * Tag component shows a label with optional remove button. Useful for tags
 * and chips in forms or filters. When `onRemove` is provided, a small
 * remove icon appears on the right and clicking it will call the handler.
 */
export interface TagProps {
  children: React.ReactNode;
  onRemove?: () => void;
  className?: string;
}

export function Tag({ children, onRemove, className = "" }: TagProps) {
  return (
    <span
      className={`inline-flex items-center rounded-md bg-muted px-2 py-0.5 text-sm text-muted-foreground ${className}`.trim()}
    >
      {children}
      {onRemove && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          aria-label="Remove tag"
          className="ml-1 inline-flex h-4 w-4 items-center justify-center rounded-full hover:bg-muted-foreground/10"
        >
          <FontAwesomeIcon icon={faTimes} className="h-3 w-3" />
        </button>
      )}
    </span>
  );
}

export default Tag;