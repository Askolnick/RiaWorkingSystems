"use client";

import React from 'react';

/**
 * Badge component displays a small pill used for status or counts.
 * It accepts a `variant` to control the background colour. You can extend
 * variants in the future to match your theme tokens. Default variant is
 * neutral (uses the `bg-muted` class).
 */
export interface BadgeProps {
  children: React.ReactNode;
  variant?: "neutral" | "primary" | "success" | "danger";
  className?: string;
}

export function Badge({ children, variant = "neutral", className = "" }: BadgeProps) {
  const variantClass = {
    neutral: "bg-muted text-muted-foreground",
    primary: "bg-primary text-primary-foreground",
    success: "bg-success text-success-foreground",
    danger: "bg-danger text-danger-foreground",
  }[variant];
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${variantClass} ${className}`.trim()}
    >
      {children}
    </span>
  );
}

export default Badge;