"use client";

import React, { createContext, useContext, useState, useCallback } from 'react';

interface ToastMessage {
  id: number;
  content: React.ReactNode;
  variant?: 'default' | 'success' | 'error';
  duration?: number;
}

interface ToastContextValue {
  addToast: (content: React.ReactNode, options?: { variant?: 'default' | 'success' | 'error'; duration?: number }) => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

let toastCounter = 0;

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((content: React.ReactNode, options: { variant?: 'default' | 'success' | 'error'; duration?: number } = {}) => {
    const id = ++toastCounter;
    const toast: ToastMessage = { id, content, variant: options.variant ?? 'default', duration: options.duration ?? 3000 };
    setToasts((prev) => [...prev, toast]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, toast.duration);
  }, []);

  return (
    <ToastContext.Provider value={{ addToast }}>
      {children}
      {/* Toast container */}
      <div className="fixed inset-x-0 bottom-4 z-50 flex flex-col items-center space-y-2">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`mx-auto rounded-md px-4 py-2 shadow-md text-sm text-bg ${toast.variant === 'error' ? 'bg-danger' : toast.variant === 'success' ? 'bg-success' : 'bg-muted'} ${toast.variant === 'error' ? 'text-danger-foreground' : toast.variant === 'success' ? 'text-success-foreground' : 'text-muted-foreground'}`}
          >
            {toast.content}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}

export default { ToastProvider, useToast };