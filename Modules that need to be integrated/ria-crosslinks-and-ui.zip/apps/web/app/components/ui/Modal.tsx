"use client";

import React from 'react';

/**
 * Simple modal component using a portal. It renders its children in
 * a centered box when `open` is true. Clicking on the backdrop or
 * pressing escape will trigger `onClose` if provided.
 */
export interface ModalProps {
  open: boolean;
  onClose?: () => void;
  children: React.ReactNode;
}

export function Modal({ open, onClose, children }: ModalProps) {
  React.useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape' && open) {
        onClose?.();
      }
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4"
      onClick={() => onClose?.()}
    >
      <div
        className="max-h-[90%] w-full max-w-lg overflow-auto rounded-lg bg-bg p-6 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}

export default Modal;