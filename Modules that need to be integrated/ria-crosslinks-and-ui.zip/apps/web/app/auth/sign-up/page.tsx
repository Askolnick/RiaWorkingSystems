"use client";

import { useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Input, Button } from '@ria/web-ui';
import { createMockAuth } from '@ria/auth-client';

// Enhanced sign-up page using shared Input and Button components. The
// mock auth client persists sessions in localStorage for demonstration.
export default function SignUpPage() {
  const router = useRouter();
  const auth = createMockAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    auth.getSession().then((session) => {
      if (session) {
        router.replace('/portal');
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await auth.signUp(name, email, password);
      router.replace('/portal');
    } catch (err) {
      setError('Unable to sign up');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg text-text p-4">
      <div className="w-full max-w-md space-y-4">
        <h1 className="text-2xl font-bold">Create Account</h1>
        {error && <p className="text-danger text-sm">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col space-y-2">
            <label htmlFor="name" className="text-sm">Name</label>
            <Input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="Your full name"
            />
          </div>
          <div className="flex flex-col space-y-2">
            <label htmlFor="email" className="text-sm">Email</label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@example.com"
            />
          </div>
          <div className="flex flex-col space-y-2">
            <label htmlFor="password" className="text-sm">Password</label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" className="w-full">Sign Up</Button>
        </form>
        <p className="text-sm">
          Already have an account?{' '}
          <Link href="/auth/sign-in" className="underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}