"use client";

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Input, Button } from '@ria/web-ui';
import { createMockAuth } from '@ria/auth-client';

// Enhanced sign-in page that uses the shared Input and Button components.
// It still uses the mock auth client to persist sessions. If a session
// exists, the user is redirected to the portal. Errors are shown below
// the form.
export default function SignInPage() {
  const router = useRouter();
  const auth = createMockAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    auth.getSession().then((session) => {
      if (session) {
        router.replace('/portal');
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await auth.signIn(email, password);
      router.replace('/portal');
    } catch (err) {
      setError('Invalid email or password');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg text-text p-4">
      <div className="w-full max-w-md space-y-4">
        <h1 className="text-2xl font-bold">Sign In</h1>
        {error && <p className="text-danger text-sm">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col space-y-2">
            <label htmlFor="email" className="text-sm">Email</label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@example.com"
            />
          </div>
          <div className="flex flex-col space-y-2">
            <label htmlFor="password" className="text-sm">Password</label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
          </div>
          <Button type="submit" className="w-full">Sign In</Button>
        </form>
        <p className="text-sm">
          Don’t have an account?{' '}
          <Link href="/auth/sign-up" className="underline">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}