export type ID = string

export type LinkKind =
  | 'references'
  | 'duplicates'
  | 'relates'
  | 'depends_on'
  | 'blocked_by'

export interface EntityLink {
  id: ID
  fromType: string
  fromId: ID
  toType: string
  toId: ID
  kind: LinkKind
  note?: string
  createdAt: string
  createdBy: ID
}