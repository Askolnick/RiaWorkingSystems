import type { RiaLinks, LinksApi } from './api'
import type { EntityLink } from './types'

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))
const now = () => new Date().toISOString()
const rid = (prefix = 'ln'): string => prefix + '-' + Math.random().toString(36).slice(2, 8)

// In-memory store for links. In a real implementation this would be persisted in a database.
let links: EntityLink[] = [
  {
    id: 'ln-1',
    fromType: 'thread',
    fromId: 't2',
    toType: 'task',
    toId: 'tsk-2',
    kind: 'references',
    createdAt: now(),
    createdBy: 'me',
  },
]

export function createMockLinks(): RiaLinks {
  const api: LinksApi = {
    async listLinks(entity) {
      await delay(30)
      return links.filter(
        (l) =>
          (l.fromType === entity.type && l.fromId === entity.id) ||
          (l.toType === entity.type && l.toId === entity.id)
      )
    },
    async createLink(input) {
      await delay(40)
      const link: EntityLink = {
        id: rid(),
        fromType: input.from.type,
        fromId: input.from.id,
        toType: input.to.type,
        toId: input.to.id,
        kind: input.kind || 'relates',
        note: input.note,
        createdAt: now(),
        createdBy: 'me',
      }
      links = [link, ...links]
      return link
    },
    async deleteLink(id) {
      await delay(20)
      links = links.filter((l) => l.id !== id)
    },
  }
  return { links: api }
}