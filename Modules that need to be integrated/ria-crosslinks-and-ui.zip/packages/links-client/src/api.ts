import type { ID, EntityLink, LinkKind } from './types'

// API surface for links; use this interface for both mock and real implementations.
export interface LinksApi {
  /**
   * List links connected to a given entity. Returns all links where the entity
   * appears as either the source or the target.
   */
  listLinks(entity: { type: string; id: ID }): Promise<EntityLink[]>

  /**
   * Create a new link connecting two entities. If kind is not provided it
   * defaults to `relates`.
   */
  createLink(input: {
    from: { type: string; id: ID }
    to: { type: string; id: ID }
    kind?: LinkKind
    note?: string
  }): Promise<EntityLink>

  /**
   * Remove an existing link.
   */
  deleteLink(id: ID): Promise<void>
}

// Container interface to allow tree‑shaking usage.
export interface RiaLinks {
  links: LinksApi
}