# Linking Across Centers

This module introduces the ability to link entities across the different hubs (Messaging, Tasks, Library, etc.) in Ria. Links let you represent relationships between records without embedding them directly. For example, you can link a support thread to a task or attach a wiki document to a project.

## Models

The primary model is `EntityLink` with the following attributes:

- `id` – unique identifier
- `tenantId` – multi‑tenant key
- `fromType` / `fromId` – entity type and ID for the source
- `toType` / `toId` – entity type and ID for the target
- `kind` – optional enum describing the relationship (`references`, `duplicates`, `relates`, `depends_on`, `blocked_by`)
- `note` – optional free text comment
- `createdAt` – timestamp

You can find the Prisma definition in `packages/db/prisma/_links.prisma`.

## API

The `@ria/links-client` package exports a `LinksApi` interface with:

- `listLinks({ entityType, entityId })` – returns all links where the entity is either source or target
- `createLink({ from, to, kind, note })` – creates a new link
- `deleteLink(linkId)` – removes a link

A mock implementation is provided for development; swap it for a real implementation once your backend exposes these endpoints.

## UI Components

Use the provided `Avatar`, `Badge`, `Tag`, `Textarea`, `Modal`, and `Toast` components to build consistent interfaces across hubs.

### Linked Panel

Each hub can display a **Linked** panel showing all related entities:

```tsx
import { useEffect, useState } from 'react';
import { createMockLinks } from '@ria/links-client';

function LinkedPanel({ type, id }: { type: string; id: string }) {
  const linksApi = createMockLinks();
  const [links, setLinks] = useState([]);
  useEffect(() => {
    linksApi.listLinks({ entityType: type, entityId: id }).then(setLinks);
  }, [type, id]);
  return (
    <aside className="space-y-2">
      <h3 className="font-semibold">Linked</h3>
      {links.map((link) => (
        <div key={link.id} className="text-sm">
          {link.kind}: {link.toType} #{link.toId}
        </div>
      ))}
    </aside>
  );
}
```

### Creating Links

Offer a dialog (using the provided `Modal` and `Tag` components) to search for an entity and create a link to it. Once a link is created, refresh the list via `listLinks()`.

## Integrating with Existing Hubs

To enable linking in your existing pages:

1. Import and render a `LinkedPanel` component in the side bar of your detail views (threads, tasks, documents, etc.).
2. Provide UI controls (e.g., “Link…”) that open a `Modal` where users can pick the target entity and call `createLink()`.
3. On deletion of an entity, cascade delete its links or handle gracefully.
4. Index links in search to surface related content.

Refer to the mock pages provided in this overlay for examples of how to use the APIs and components.